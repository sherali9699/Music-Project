import React from 'react';

const StudentWorks = () => {
  return (
    <div>
      <h1>Student Works</h1>
      <p>Information about student works.</p>
    </div>
  );
};

export default StudentWorks;
