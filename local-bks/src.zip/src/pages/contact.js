import React from 'react';

const Contact = () => {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Contact information.</p>
    </div>
  );
};

export default Contact;
